
A simple package to count number of vowels and consonants in a string.

## How to install

```
pip install vcons
```
## If you are trouble installing, try this
```
pip3 install vcons
```
## How to use

Below example will help you

```
from vcons import vcons
sample_string= "python"
vcons.vowels(sample_string)	# returns the number of vowels in the given string

sample_string = "PACKAGE"
vcons.consonants(sample_string)     #returns the number of consonants in the given string

```



